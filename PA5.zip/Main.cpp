#include "PA5.h"

int main() {
    runMusicManager();
    
    return 0;
}