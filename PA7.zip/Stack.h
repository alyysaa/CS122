#ifndef STACK_H
#define STACK_H

// both .h and .cpp are needed because of where the template implementations are
// .cpp includes the .h
#include "LinkedList.cpp"

template <typename T>
class Stack : private LinkedList<T> {
public:

    /// @copydoc Stack()
    Stack();

    /// @copydoc ~Stack()
    ~Stack();

    /// @copydoc push(T)
    void push(T);

    /// @copydoc pop()
    T pop();

    /// @copydoc peek()
    T peek();

    /// @copydoc isEmpty()
    bool isEmpty();
};

#endif
