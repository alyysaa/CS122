#include "Pointers.h"

int main()
{
  task1("./PA3/numbers.txt");
  task2();
  task3("./PA3/input_words.txt");
  return 0;
}