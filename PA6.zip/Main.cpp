#include "SLUI.h"

int main(int argc, char *argv[]) {

    //testCopy(); //uncomment to test copy constructor, comment out runMusic
    runMusic(argc, argv);
    return 0;
}